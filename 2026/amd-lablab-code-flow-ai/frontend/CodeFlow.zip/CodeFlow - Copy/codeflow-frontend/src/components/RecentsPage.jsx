import { useState, useEffect } from "react";
import { supabase } from "../supabaseClient";

const RecentsPage = ({ setCurrentPage, showNotification }) => {
  const [recents, setRecents] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    setLoading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('diagrams')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setRecents(data || []);
    } catch (err) {
      console.error("Fetch Error:", err.message);
      showNotification("Failed to load recents", "error");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleDelete = async (id) => {
    const { error } = await supabase.from('diagrams').delete().eq('id', id);
    if (!error) {
      setRecents(prev => prev.filter(item => item.id !== id));
      showNotification("Record deleted!", "success");
    } else {
      showNotification("Delete failed", "error");
    }
  };

  if (loading) return <div className="text-gray-400 p-10 italic animate-pulse">Fetching your history...</div>;

  return (
    <div className="w-full p-6 bg-[#1A1A2E]" style={{ minHeight: "calc(100vh - 65px)" }}>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-white text-xl font-bold">Recent Diagrams</h2>
        <button onClick={fetchData} className="text-xs text-orange-500 hover:underline">Refresh List</button>
      </div>

      {recents.length === 0 ? (
        <div className="text-gray-500 text-center mt-20 border border-dashed border-gray-800 p-10 rounded-2xl">
          No records found. Generate some diagrams first!
        </div>
      ) : (
        <div className="grid gap-4 grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
          {recents.map((item) => (
            <div key={item.id} className="p-4 rounded-xl border border-gray-700 bg-[#12122A] flex flex-col gap-3 hover:border-orange-500/50 transition-all group">
              <div className="flex justify-between items-start">
                <span className="text-white font-semibold text-sm truncate w-4/5">{item.title}</span>
                <button 
                  onClick={() => handleDelete(item.id)} 
                  className="text-gray-600 hover:text-red-500 transition-colors"
                  title="Delete record"
                >
                  🗑
                </button>
              </div>
              <div className="p-2 bg-[#0D0D1A] rounded text-[10px] text-gray-500 font-mono h-12 overflow-hidden italic border border-gray-800">
                {item.code || "No code snippet"}
              </div>
              <button 
                onClick={() => setCurrentPage("main")} 
                className="w-full py-2 rounded-lg text-xs font-semibold text-white bg-[#E8611A] hover:bg-orange-600 shadow-lg shadow-orange-900/20"
              >
                View Analysis
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default RecentsPage;