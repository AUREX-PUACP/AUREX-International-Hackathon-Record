const TopBar = ({ currentPage, setCurrentPage, userName }) => {
  return (
    <div className="w-full flex items-center justify-between px-6 py-4 border-b border-gray-700"
      style={{ backgroundColor: "#1A1A2E", minHeight: "65px" }}>

      {/* Left — Logo */}
      <div className="flex items-center gap-3">
        <div className="w-9 h-9 rounded flex items-center justify-center font-bold text-white"
          style={{ backgroundColor: "#E8611A" }}>
          A
        </div>
        <div>
          <div className="font-bold text-white text-sm">AUREX</div>
          <div className="text-gray-400 text-xs">AI Labs</div>
        </div>
      </div>

      {/* Center — Title */}
      <span className="absolute left-1/2 transform -translate-x-1/2 font-bold text-xl tracking-wide"
        style={{ color: "#E8611A" }}>
        CODE-FLOW AI
      </span>

      {/* Right — Icons */}
      <div className="flex items-center gap-4">
        <button className="text-gray-400 hover:text-white text-xl">🔔</button>
        <button
          onClick={() => setCurrentPage("login")}
          className="w-9 h-9 rounded-full flex items-center justify-center text-white font-bold transition-all hover:opacity-80"
          style={{ backgroundColor: "#E8611A" }}
          title={userName ? userName : "Login"}>
          {userName ? userName.charAt(0).toUpperCase() : "U"}
        </button>
      </div>

    </div>
  );
}

export default TopBar;