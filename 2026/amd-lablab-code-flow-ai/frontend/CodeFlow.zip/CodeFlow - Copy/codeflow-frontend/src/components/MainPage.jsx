import { useState, useEffect } from "react";
import mermaid from "mermaid";
import { supabase } from "../supabaseClient";

// Mermaid initialization for Dark Theme
mermaid.initialize({
  startOnLoad: false,
  theme: "dark",
  securityLevel: "loose",
  flowchart: { useMaxWidth: true, htmlLabels: true, curve: "basis" },
});

const MainPage = ({ showNotification }) => {
  const [code, setCode] = useState("");
  const [mermaidText, setMermaidText] = useState("");
  const [redZones, setRedZones] = useState([]);
  const [loading, setLoading] = useState(false);
  const [diagramSvg, setDiagramSvg] = useState("");

  // Re-render diagram whenever mermaidText changes
  useEffect(() => {
    if (mermaidText) {
      const renderDiagram = async () => {
        try {
          const { svg } = await mermaid.render("mermaid-diagram", mermaidText);
          setDiagramSvg(svg);
        } catch (error) {
          console.error("Mermaid Render Error:", error);
          setDiagramSvg("");
        }
      };
      renderDiagram();
    }
  }, [mermaidText]);

  const handleAnalyze = async () => {
    if (!code.trim()) {
      showNotification("Please paste your code first!", "error");
      return;
    }

    setLoading(true);
    setMermaidText("");
    setDiagramSvg("");
    showNotification("AI Model is analyzing your backend architecture... ⏳", "info");

    // Simulation of AI Analysis (Mock Logic)
    setTimeout(async () => {
      // Mermaid code with CSS Class Definitions for styling
      const generatedMermaid = `
flowchart TD
    %% Styling Definitions
    classDef risk fill:#A32D2D,stroke:#fff,stroke-width:2px,color:#fff;
    classDef safe fill:#0F6E56,stroke:#fff,stroke-width:1px,color:#fff;
    classDef neutral fill:#12122A,stroke:#374151,stroke-width:1px,color:#9CA3AF;

    A[Client Request]:::neutral --> B[FastAPI Router]:::safe
    B --> C{Auth Middleware}:::risk
    C -- No Token --> D[401 Unauthorized]:::neutral
    C -- Valid --> E[Database Query]:::safe
    E --> F[(PostgreSQL)]:::safe

    %% Highlighting the specific risk node
    class C risk;
      `.trim();

      const detectedIssues = [
        { 
          id: "C", 
          type: "Broken Authentication", 
          location: "main.py, Line 24", 
          fix: "JWT secret key is hardcoded. Move it to environment variables." 
        }
      ];

      setMermaidText(generatedMermaid);
      setRedZones(detectedIssues);
      setLoading(false);
      showNotification("Analysis Complete! Risks highlighted in red. 🛡️", "success");

      // Save to Supabase Database
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        const { error } = await supabase.from('diagrams').insert([{
          user_id: user.id,
          title: `Audit: ${new Date().toLocaleTimeString()}`,
          code: code,
          mermaid_text: generatedMermaid,
          red_zones: detectedIssues
        }]);
        
        if (error) console.error("Database Save Error:", error.message);
      }
    }, 2500);
  };

  return (
    <div className="flex w-full" style={{ minHeight: "calc(100vh - 65px)", backgroundColor: "#1A1A2E" }}>
      
      {/* Left Panel: Input Area */}
      <div className="flex flex-col p-6 border-r border-gray-700 w-1/2">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-gray-300 font-semibold text-sm uppercase tracking-wider">1. Paste Backend Logic</h2>
          <span className="text-[10px] px-2 py-1 rounded bg-gray-800 text-gray-400 border border-gray-700">Python / FastAPI</span>
        </div>
        
        <textarea
          className="flex-1 w-full p-4 rounded-xl text-sm font-mono outline-none border border-gray-700 focus:border-orange-500 bg-[#0D0D1A] text-[#E0E0E0] resize-none"
          value={code}
          onChange={(e) => setCode(e.target.value)}
          placeholder="# Paste your code here to detect vulnerabilities..."
        />

        <button 
          onClick={handleAnalyze} 
          disabled={loading}
          className="mt-4 py-3 rounded-xl font-bold text-white transition-all hover:opacity-90 shadow-lg"
          style={{ backgroundColor: loading ? "#4B5563" : "#E8611A" }}
        >
          {loading ? "⚙️ Processing..." : "▶ Run Security Analysis"}
        </button>
      </div>

      {/* Right Panel: Visualization & Risks */}
      <div className="flex flex-col p-6 w-1/2 bg-[#12122A]">
        <h2 className="text-gray-300 font-semibold text-sm uppercase mb-3">2. Security Flow Diagram</h2>
        
        <div className="flex-1 flex flex-col gap-4">
          {/* Diagram Container */}
          <div className="flex-[2] overflow-auto bg-[#1A1A2E] p-4 rounded-xl border border-gray-700 flex justify-center items-center">
            {loading ? (
              <div className="text-orange-500 animate-pulse text-sm">AI is mapping your architecture...</div>
            ) : diagramSvg ? (
              <div className="w-full h-full flex justify-center" dangerouslySetInnerHTML={{ __html: diagramSvg }} />
            ) : (
              <div className="text-gray-600 text-xs italic">Your security map will generate here</div>
            )}
          </div>

          {/* Risks Summary Card */}
          {redZones.length > 0 && (
            <div className="flex-1 p-4 rounded-xl border border-red-900/30 bg-[#1A0A0A]">
              <h3 className="text-red-500 text-xs font-bold uppercase mb-2">🔴 Detected Vulnerabilities</h3>
              {redZones.map((issue, idx) => (
                <div key={idx} className="mb-2 last:mb-0 border-l-2 border-red-600 pl-3">
                  <div className="text-white text-xs font-semibold">{issue.type}</div>
                  <div className="text-gray-500 text-[10px]">{issue.location}</div>
                  <div className="text-green-500 text-[10px] mt-1 italic">Fix: {issue.fix}</div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default MainPage;