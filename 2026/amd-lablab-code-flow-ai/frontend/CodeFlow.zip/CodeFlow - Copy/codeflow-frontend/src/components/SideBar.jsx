const SideBar = ({ currentPage, setCurrentPage }) => {
  return (
    <div className="flex flex-col items-center py-6 gap-6 border-r border-gray-700"
      style={{ backgroundColor: "#12122A", width: "60px", minHeight: "calc(100vh - 65px)" }}>

      {/* Dashboard */}
      <button
        onClick={() => setCurrentPage("main")}
        className={`p-2 rounded-lg transition-all ${currentPage === "main" ? "bg-gray-700" : "hover:bg-gray-700"}`}
        title="Dashboard">
        <svg width="22" height="22" fill="none" stroke={currentPage === "main" ? "#E8611A" : "gray"} strokeWidth="2" viewBox="0 0 24 24">
          <rect x="3" y="3" width="7" height="7" rx="1"/>
          <rect x="14" y="3" width="7" height="7" rx="1"/>
          <rect x="3" y="14" width="7" height="7" rx="1"/>
          <rect x="14" y="14" width="7" height="7" rx="1"/>
        </svg>
      </button>

      {/* Recents */}
      <button
        onClick={() => setCurrentPage("recents")}
        className={`p-2 rounded-lg transition-all ${currentPage === "recents" ? "bg-gray-700" : "hover:bg-gray-700"}`}
        title="Recents">
        <svg width="22" height="22" fill="none" stroke={currentPage === "recents" ? "#E8611A" : "gray"} strokeWidth="2" viewBox="0 0 24 24">
          <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
          <polyline points="14 2 14 8 20 8"/>
          <line x1="16" y1="13" x2="8" y2="13"/>
          <line x1="16" y1="17" x2="8" y2="17"/>
        </svg>
      </button>

      {/* Login */}
      <button
        onClick={() => setCurrentPage("login")}
        className={`p-2 rounded-lg transition-all ${currentPage === "login" ? "bg-gray-700" : "hover:bg-gray-700"}`}
        title="Login">
        <svg width="22" height="22" fill="none" stroke={currentPage === "login" ? "#E8611A" : "gray"} strokeWidth="2" viewBox="0 0 24 24">
          <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
          <circle cx="12" cy="7" r="4"/>
        </svg>
      </button>

    </div>
  );
}

export default SideBar;