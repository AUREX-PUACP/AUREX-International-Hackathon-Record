const Notification = ({ message, type }) => {
  if (!message) return null;

  const bgColor = type === "success" ? "#0F6E56"
    : type === "error" ? "#A32D2D"
    : type === "info" ? "#185FA5"
    : "#E8611A";

  const icon = type === "success" ? "✅"
    : type === "error" ? "❌"
    : type === "info" ? "⏳"
    : "🔔";

  return (
    <div className="fixed top-4 right-4 z-50 flex items-center gap-3 px-5 py-3 rounded-xl shadow-lg"
      style={{ backgroundColor: bgColor, minWidth: "280px", maxWidth: "400px" }}>
      <span className="text-lg">{icon}</span>
      <span className="text-white text-sm font-medium">{message}</span>
    </div>
  );
}

export default Notification;