import { useState } from "react";
import { supabase } from "../supabaseClient";

const LogInPage = ({ setCurrentPage, setUserName, showNotification }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    if (!email || !password) {
      showNotification("Please fill all fields!", "error");
      return;
    }
    setLoading(true);

    try {
      if (isLogin) {
        const { data, error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        setUserName(data.user.user_metadata?.full_name || data.user.email.split("@")[0]);
        showNotification("Login successful! ✨", "success");
      } else {
        if (!name) throw new Error("Please enter your name!");
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: { data: { full_name: name } }
        });
        if (error) throw error;
        showNotification("Signup successful! Please verify your email.", "success");
      }
      setCurrentPage("main");
    } catch (err) {
      showNotification(err.message, "error");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex items-center justify-center w-full" style={{ minHeight: "calc(100vh - 65px)", backgroundColor: "#1A1A2E" }}>
      <div className="p-8 rounded-2xl border border-gray-700 w-full max-w-md" style={{ backgroundColor: "#12122A" }}>
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl flex items-center justify-center font-bold text-white text-lg" style={{ backgroundColor: "#E8611A" }}>A</div>
          <div>
            <div className="text-white font-bold text-lg">{isLogin ? "Welcome Back" : "Create Account"}</div>
            <div className="text-gray-400 text-xs">{isLogin ? "Login to Code-Flow AI" : "Sign up for Code-Flow AI"}</div>
          </div>
        </div>
        <div className="border-b border-gray-700 mb-6" />
        {!isLogin && (
          <div className="mb-4">
            <label className="text-gray-400 text-sm mb-1 block">Full Name</label>
            <input type="text" value={name} onChange={(e) => setName(e.target.value)} placeholder="Enter your name" className="w-full px-4 py-3 rounded-lg text-white text-sm outline-none border border-gray-600 focus:border-orange-500 transition-all bg-[#0D0D1A]" />
          </div>
        )}
        <div className="mb-4">
          <label className="text-gray-400 text-sm mb-1 block">Email</label>
          <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Enter your email" className="w-full px-4 py-3 rounded-lg text-white text-sm outline-none border border-gray-600 focus:border-orange-500 transition-all bg-[#0D0D1A]" />
        </div>
        <div className="mb-6">
          <label className="text-gray-400 text-sm mb-1 block">Password</label>
          <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Enter your password" className="w-full px-4 py-3 rounded-lg text-white text-sm outline-none border border-gray-600 focus:border-orange-500 transition-all bg-[#0D0D1A]" />
        </div>
        <button onClick={handleSubmit} disabled={loading} className="w-full py-3 rounded-xl font-semibold text-white transition-all hover:opacity-90 mb-4 bg-[#E8611A]">
          {loading ? "Processing..." : isLogin ? "Login" : "Sign Up"}
        </button>
        <p className="text-gray-400 text-sm text-center">
          {isLogin ? "Don't have an account? " : "Already have an account? "}
          <button onClick={() => setIsLogin(!isLogin)} className="font-semibold hover:underline text-[#E8611A]">{isLogin ? "Sign Up" : "Login"}</button>
        </p>
      </div>
    </div>
  );
};

export default LogInPage;