import { useState, useEffect } from "react";
import { supabase } from "./supabaseClient"; // Ensure your client is exported correctly
import TopBar from "./components/TopBar";
import SideBar from "./components/SideBar";
import MainPage from "./components/MainPage";
import RecentsPage from "./components/RecentsPage";
import LogInPage from "./components/LogInPage";
import Notification from "./components/Notification";

function App() {
  const [currentPage, setCurrentPage] = useState("login"); // Start at login
  const [userName, setUserName] = useState("");
  const [notification, setNotification] = useState({ message: "", type: "" });

  // 1. Session Persistence & Auth Listener
  useEffect(() => {
    // Check current session on load
    const checkUser = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (session) {
        setUserName(session.user.user_metadata?.full_name || session.user.email.split("@")[0]);
        setCurrentPage("main");
      }
    };
    checkUser();

    // Listen for auth changes (Login/Logout)
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      if (session) {
        setUserName(session.user.user_metadata?.full_name || session.user.email.split("@")[0]);
      } else {
        setUserName("");
        setCurrentPage("login");
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  // 2. Notification Timer
  useEffect(() => {
    if (notification.message) {
      const timer = setTimeout(() => {
        setNotification({ message: "", type: "" });
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [notification]);

  const showNotification = (message, type = "default") => {
    setNotification({ message, type });
  };

  return (
    <div className="min-h-screen flex flex-col" style={{ backgroundColor: "#1A1A2E" }}>
      
      <Notification message={notification.message} type={notification.type} />

      {/* Show Navigation only if NOT on Login page */}
      {currentPage !== "login" && (
        <TopBar
          currentPage={currentPage}
          setCurrentPage={setCurrentPage}
          userName={userName}
        />
      )}

      <div className="flex flex-1">
        {/* Show Sidebar only if NOT on Login page */}
        {currentPage !== "login" && (
          <SideBar currentPage={currentPage} setCurrentPage={setCurrentPage} />
        )}

        <div className="flex-1">
          {currentPage === "main" && (
            <MainPage
              showNotification={showNotification}
              userName={userName}
            />
          )}

          {currentPage === "recents" && (
            <RecentsPage
              userName={userName}
              setCurrentPage={setCurrentPage}
              showNotification={showNotification}
            />
          )}

          {currentPage === "login" && (
            <LogInPage
              setCurrentPage={setCurrentPage}
              setUserName={setUserName}
              showNotification={showNotification}
            />
          )}
        </div>
      </div>
    </div>
  );
}

export default App;